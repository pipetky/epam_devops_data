wc -w /etc/homework7/textfile.txt  | awk '{print $1}'
